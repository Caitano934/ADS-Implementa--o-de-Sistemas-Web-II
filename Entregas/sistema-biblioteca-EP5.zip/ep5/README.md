# 📚 Sistema de Biblioteca

**Equipe:** Hezron Daniel M C Canturil | Leandro Caitano dos Santos | Luilson Vieira Martins
**Polo:** Sobradinho — BA
**Repositório:** https://github.com/luilsonvmartins/Projeto-e-Implementa-o-de-Sistemas-para-Web-2

## Como rodar
1. Extraia dentro de `C:\xampp\htdocs\sistema-biblioteca`
2. Inicie Apache e MySQL no XAMPP
3. phpMyAdmin → aba SQL → cole `banco.sql` → Executar
4. Acesse: `http://localhost/sistema-biblioteca/public`
5. Login admin: `admin@biblioteca.com` / `admin123`
6. Login leitor: `leitor@biblioteca.com` / `leitor123`

## Entregas
| Entrega | Status |
|---------|--------|
| EP1 — Planejamento | ✅ |
| EP2 — MVC e Rotas  | ✅ |
| EP3 — CRUD Inicial | ✅ |
| EP4 — CRUD Completo| ✅ |
| EP5 — Autenticação | ✅ |
| Final              | ⏳ |
